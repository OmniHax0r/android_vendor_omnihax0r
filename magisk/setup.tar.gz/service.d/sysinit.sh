#!/system/bin/sh
/system/xbin/sysinit

